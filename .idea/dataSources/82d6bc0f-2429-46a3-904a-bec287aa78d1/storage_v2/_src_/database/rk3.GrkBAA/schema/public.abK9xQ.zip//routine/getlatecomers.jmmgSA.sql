create function getlatecomers(date)
    returns TABLE(latetime time without time zone, quantity integer)
    language sql
as
$$
select (timet - '09:00:00') , count(ID)
    from(
        select timet, id
	    from uchet
	    where Date = $1 and type = 1 and timet > '09:00:00'
        group by id,timet
        ) as Latecomers
    group by timet

$$;

alter function getlatecomers(date) owner to postgres;

