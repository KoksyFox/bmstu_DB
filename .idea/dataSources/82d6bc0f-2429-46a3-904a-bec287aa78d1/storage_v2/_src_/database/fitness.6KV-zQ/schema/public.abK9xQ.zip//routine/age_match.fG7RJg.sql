create procedure age_match(INOUT is_match boolean)
    language plpgsql
as
$$
begin
    is_match = (select min(cnt.count) from (select count(*)
    over (partition by age)
    from visitors) as cnt) = 1;
    --raise notice 'is match: %', is_match;
end;
$$;

alter procedure age_match(inout boolean) owner to postgres;

