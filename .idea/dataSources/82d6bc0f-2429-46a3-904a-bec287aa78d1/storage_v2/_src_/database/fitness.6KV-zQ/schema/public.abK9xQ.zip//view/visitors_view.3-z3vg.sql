create view visitors_view(id, idcard, name, gender, age) as
SELECT visitors.id,
       visitors.idcard,
       visitors.name,
       visitors.gender,
       visitors.age
FROM visitors;

alter table visitors_view
    owner to postgres;

