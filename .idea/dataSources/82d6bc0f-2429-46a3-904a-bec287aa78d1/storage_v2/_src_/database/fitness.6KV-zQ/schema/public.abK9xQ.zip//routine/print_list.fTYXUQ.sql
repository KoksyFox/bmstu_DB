create procedure print_list(gym_id integer)
    language plpgsql
as
$$
declare
    list cursor for select * from abonements where abonements.idgym = gym_id order by validity;
    rec record;
begin
    raise notice 'Список абонементов зала № % ', gym_id;
    for rec in list loop
        raise notice 'id: %  validity: %', rec.id, rec.validity;
    end loop;
end
$$;

alter procedure print_list(integer) owner to postgres;

