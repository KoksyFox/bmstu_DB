create function add_new_visitors() returns trigger
    language plpgsql
as
$$
begin
    insert into new_visitors(name, IDcard, age) values(new.name, new.Idcard, new.age);
    return new;
end;
$$;

alter function add_new_visitors() owner to postgres;

