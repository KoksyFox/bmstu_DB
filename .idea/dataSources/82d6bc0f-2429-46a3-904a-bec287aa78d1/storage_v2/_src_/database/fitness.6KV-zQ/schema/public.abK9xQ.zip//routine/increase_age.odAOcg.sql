create function increase_age() returns trigger
    language plpgsql
as
$$
begin
    update visitors_view
    set age = old.age + 10
    where id = old.id;
    return null;
end;
$$;

alter function increase_age() owner to postgres;

