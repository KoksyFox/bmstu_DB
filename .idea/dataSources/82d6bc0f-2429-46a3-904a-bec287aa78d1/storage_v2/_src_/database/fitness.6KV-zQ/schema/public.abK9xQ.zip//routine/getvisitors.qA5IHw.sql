create function getvisitors(integer) returns visitors
    language sql
as
$$
select *
	from visitors
	where age = $1;
$$;

alter function getvisitors(integer) owner to postgres;

