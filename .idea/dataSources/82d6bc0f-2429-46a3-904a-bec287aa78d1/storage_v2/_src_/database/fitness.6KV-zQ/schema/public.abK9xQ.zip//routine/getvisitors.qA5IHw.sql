create function getvisitors(findage integer)
    returns TABLE(id integer, idcard integer, name character varying, gender character, age integer)
    language plpgsql
as
$$
begin
    return query
	select *
	from visitors
	where visitors.age = findage;
end;
$$;

alter function getvisitors(integer) owner to postgres;

