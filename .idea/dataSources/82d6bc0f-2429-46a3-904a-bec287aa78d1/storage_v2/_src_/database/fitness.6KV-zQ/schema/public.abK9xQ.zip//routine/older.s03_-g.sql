create function older(id1 integer, id2 integer) returns integer
    language plpgsql
as
$$
declare
age1 int;
age2 int;
begin
    age1 = (select age from visitors where id = id1);
    age2 = (select age from visitors where id = id2);

    if age1 > age2 then
        return id1;
    else
        return id2;
    end if;
end;
$$;

alter function older(integer, integer) owner to postgres;

