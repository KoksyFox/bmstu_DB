create function a1() returns character varying
    language sql
as
$$
select count(name)
	from visitors
	where age = 25
$$;

alter function a1() owner to postgres;

