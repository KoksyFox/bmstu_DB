create procedure count_tables()
    language plpgsql
as
$$
declare cnt int;
begin
    cnt = (select count(*)
           from pg_tables
           where tableowner in (
               select usename
               from pg_user));

    raise notice 'In system % users tables', cnt;
end
$$;

alter procedure count_tables() owner to postgres;

