create function a1(fage integer) returns character varying
    language sql
as
$$
select count(name)
	from visitors
	where age = fage
$$;

alter function a1(integer) owner to postgres;

