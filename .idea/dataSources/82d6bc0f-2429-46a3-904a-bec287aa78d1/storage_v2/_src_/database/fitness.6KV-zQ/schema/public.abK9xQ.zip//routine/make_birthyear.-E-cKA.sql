create procedure make_birthyear(i integer)
    language plpgsql
as
$$
begin
    if i <= (select count(*) from tmp2) then
        update tmp2
        set year = Extract(year from current_date) - age
        where id = i;

        call make_birthyear(i+1);
    end if;
end;
$$;

alter procedure make_birthyear(integer) owner to postgres;

